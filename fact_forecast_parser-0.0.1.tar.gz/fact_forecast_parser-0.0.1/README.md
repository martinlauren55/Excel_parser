# FACT-FORECAST PARSER

Fact-forecast parser